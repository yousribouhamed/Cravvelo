import { Button } from "@ui/components/button";

export default function Page() {
  return (
    <>
      <h1>Docs</h1>
      <Button>Click me</Button>
    </>
  );
}
