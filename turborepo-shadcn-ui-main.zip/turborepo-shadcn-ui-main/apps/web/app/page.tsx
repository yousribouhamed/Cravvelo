import { Button } from "@ui/components/button";

export default function Page() {
  return (
    <>
      <h1>Web</h1>
      <Button>Click me</Button>
    </>
  );
}
