module.exports = {
  reactStrictMode: true,
  transpilePackages: ["ui"],
};
